
export const map_msg = new Map<any, any>();
